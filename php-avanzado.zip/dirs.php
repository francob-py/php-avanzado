<?php 
define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
define('CONTROLLER_PATH', ROOT_PATH.'controller/');
define('MODEL_PATH', ROOT_PATH.'model/');
define('VIEWS_PATH', ROOT_PATH.'views/');
define('EMP_PATH', VIEWS_PATH.'empleados/');
