<?php include("../includes/database.php") ?>
<?php

$id = $_POST['id_emp'];

$nombre = $_POST['nombre_emp'];

$apellido = $_POST['apellido_emp'];

$dni = $_POST['dni_emp'];

$direccion = $_POST['direccion_emp'];

$cuil = $_POST['cuil_emp'];

$sql = "UPDATE empleados SET nombre = '$nombre', apellido= '$apellido', dni='$dni', direccion = '$direccion', cuil='$cuil' WHERE id_empleados = '$id'";

if (mysqli_query($conn, $sql)) {
    header("location:../index.php?u=ok");
} else {
    echo "ERROR: " . $sql . "<br>" . $conn->error;
};
?>