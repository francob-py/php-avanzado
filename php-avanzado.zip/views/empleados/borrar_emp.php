<?php


require_once '../../controller/main.php';

$id = $_GET['emp'];

$sql = "DELETE FROM empleados WHERE id_empleados = '$id'";

$c = new Controller();

if ($c->enviarQuery($sql)) {
    header("location:../../views/empleados/consulta_emp.php?d=ok");
} else {
    $c->error = 'bdborrar';
    $c->Get404();
    // echo "ERROR: " . $sql . "<br>" . $conn->error;
};
