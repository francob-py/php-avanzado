<?php


require_once '../../controller/main.php';

$id = $_GET['tar'];

$sql = "DELETE FROM tareas WHERE id_tareas = '$id'";

$c = new Controller();

if ($c->enviarQuery($sql)) {
    header("location:../../views/tareas/consulta_tarea.php?d=ok");
} else {
    $c->error = 'bdborrar';
    $c->Get404();
    // echo "ERROR: " . $sql . "<br>" . $conn->error;
};
