<?php require_once '../../controller/main.php';

$c = new Controller();

$c->GetHeader();

$c->GetDB();

$c->GetSidebar();
?>

<!-- Contenido  -->
<main class="page-content">
    <div class="container-fluid">
        <h2>ADMINISTRAR TAREAS</h2>
        <hr>
        <div class="row">
            <div class="form-group col-md-12">
                <p> LISTA DE TAREAS </p>

            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive-sm">
                    <table class="table table-hover table-striped">
                        <tr class="table-info text-center">
                            <th>TAREA</th>
                            <th>INCIO</th>
                            <th>FIN</th>
                            <th>EDITAR</th>
                            <th>BORRAR</th>
                        </tr>

                        <!-- CONTENIDO DE TABLA CON PHP -->
                        <?php

                        $sql = "SELECT * FROM tareas ORDER BY fin DESC";

                        $registros = $c->enviarQuery($sql);

                        while (list($id, $tarea, $inicio, $fin) = mysqli_fetch_array($registros)) {
                            echo ("<tr class='text-center'>
                            <td> $tarea </td>
                            <td> $inicio</td>
                            <td> $fin </td>
                            <td> <a href='../../views/tareas/editar_tarea.php?tar=$id&tarea=$tarea&inicio=$inicio&fin=$fin' type='button' value='Editar' class='btn btn-info fa fa-edit' style='font-size:14px'> </a></td>
                            <td> <a href='../../views/tareas/borrar_tarea.php?tar=$id' type='button'value='Borrar' class='btn btn-danger fa fa-trash-alt'> </a></td>
                            </tr>");
                        };

                        ?>
                        <!-- FIN CONTENIDO DE TABLA CON PHP -->

                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="row col-md-12">
            <?php
            if (isset($_GET["export"])) {
                echo ("<h6 class='col-md-3 bg-info'> Listado exportado exitosamente <h6>");
            };
            ?>
        </div>
    </div>
    <hr>
</main>

<!-- footer -->
<?php include("../includes/footer.php") ?>