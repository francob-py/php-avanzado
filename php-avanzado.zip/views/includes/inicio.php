<?php

require_once './controller/main.php';

$c = new Controller();

$c->GetHeaderIndex();

$c->GetDBIndex();

$c->GetSidebarIndex();
?>

<main class="page-content">
    <div class="container-fluid">
        <h5>PANEL DE CONTROL</h5>
        <?php
        echo ($c->get_fecha_esp());
        ?>
    </div>
    <div class="container-fluid">
        <h5>EMPLEADOS</h5>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive-sm">
                    <table class="table table-hover table-striped">
                        <tr class="table-info text-center">
                            <th>NOMBRE</th>
                            <th>APELLIDO</th>
                            <th>DNI</th>
                            <th>DIRECCIÓN</th>
                            <th>CUIL</th>
                            <th>EDITAR</th>
                            <th>BORRAR</th>
                            <th>EXPORTAR</th>
                        </tr>

                        <!-- CONTENIDO DE TABLA CON PHP -->
                        <?php

                        $sql = "SELECT * FROM empleados ORDER BY id_empleados DESC LIMIT 5";

                        $registros = $c->enviarQuery($sql, $i = 'index');


                        while (list($id, $nombre, $apellido, $dni, $direccion, $cuil) = mysqli_fetch_array($registros)) {
                            echo ("<tr class='text-center'>
                            <td> $nombre </td>
                            <td> $apellido</td>
                            <td> $dni </td>
                            <td> $direccion </td>
                            <td> $cuil </td>
                            <td> <a href='../../views/empleados/editar_emp.php?emp=$id' type='button' class='btn btn-info fa fa-edit' style='font-size:14px'></a></td>
                            <td> <a href='../../views/empleados/borrar_emp.php?emp=$id' type='button' class='btn btn-danger fa fa-trash-alt'></a></td> 
                            <td> <a href='../../views/empleados/exportar_emp.php?emp=$id' type='button' class='btn btn-success fa fa-book'></a></td> 
                            </tr>");
                        };
                        ?>
                        <!-- FIN CONTENIDO DE TABLA CON PHP -->
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>


</main>

<?php
$c->GetFooterIndex();
?>