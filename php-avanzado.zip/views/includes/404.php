<?php require_once '../../controller/main.php';

$c = new Controller();

$c->GetHeader();

$c->GetSidebar();

?>
<main>
    <div class='container centrar-todo'>
        <h1 class="error"> ERROR 404 </h1>
        <?php

        echo ($c->get_fecha_esp());


        echo ("<h5><strong> OOPS!! ALGO SALIO MAL </strong><h5>");


        ?>
        <img class='container' src="/views/img/404.jpg" alt="">
    </div>
</main>